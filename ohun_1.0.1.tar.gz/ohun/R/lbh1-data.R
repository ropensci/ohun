#' Long-billed hermit recording
#'
#' @usage data(lbh1)
#'
#' @description \code{lbh1} a wave object with long-billed hermit (\emph{Phaethornis longirostris}) songs extracted from xeno-canto's '154138' recording.
#'
#'
#' @source Marcelo Araya-Salas
"lbh1"
