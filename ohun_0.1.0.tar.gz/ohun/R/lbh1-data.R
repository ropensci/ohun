#' Long-billed hermit recording
#'
#' @usage data(lbh1)
#'
#' @description \code{lbh1} a wave object with is a long-billed hermit songs extracted from xeno-cantos '154138' recording.
#'
#'
#' @source Marcelo Araya Salas, warbleR
"lbh1"
