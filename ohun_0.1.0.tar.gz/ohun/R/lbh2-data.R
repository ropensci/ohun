#' Long-billed hermit recording
#'
#' @usage data(lbh2)
#'
#' @description \code{lbh2} a wave object with is a long-billed hermit songs extracted from xeno-cantos '154129' recording.
#'
#'
#' @source Marcelo Araya Salas, warbleR
"lbh2"
